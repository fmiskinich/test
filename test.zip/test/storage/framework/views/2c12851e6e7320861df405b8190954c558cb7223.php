
<form>
  <div class="form-group row">
    <label for="staticEmail" class="col-sm-2 col-form-label">N° 1</label>
    <div class="col-sm-10">
      <input type="number" class="form-control" id="numero1" placeholder="Numero 1">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword" class="col-sm-2 col-form-label">N° 2</label>
    <div class="col-sm-10">
      <input type="number" class="form-control" id="numero2" placeholder="Numero 2">
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Resultado</label>
    <div class="col-sm-10">
      <input type="number" class="form-control" id="resultado" placeholder="Resultado" disabled="disabled">
    </div>
  </div>
</form>	
<center>
  <button type="button" class="btn btn-primary" id="boton">Calcular</button>
</center>
<script>

function producto(n, m){ 
	if( m < 1 )
		return 0;
	else
		return n + producto(n, m-1);
}


 $("#boton").click(function(){
 	
 	n1 = parseInt($("#numero1").val());
 	n2 = parseInt($("#numero2").val());

 	$("#resultado").val(producto(n1,n2));

 })
</script><?php /**PATH /home/fmiskinich/proyectos/test/resources/views/punto1.blade.php ENDPATH**/ ?>