<?php 


/**
 *  Convierto array multidimensional en unidimensional
 */

function flatten(array $array) {
    $return = array();
    array_walk_recursive($array, function($a) use (&$return) { $return[] = $a; });
    return $return;
}

$array = array(
          1,
          array(2, array(3,4)),
          'hola',
          array(1,0)
        );

?>


<form>
  <div class="form-group row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Array</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="vector" placeholder="Ingrese json">
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Resultado</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="resultado" placeholder="Resultado" disabled="disabled">
    </div>
  </div>
</form>	

<center>
  <button type="button" class="btn btn-primary" id="boton_borra_null">Calcular</button>
</center>

<script>

	$("#boton_borra_null").click(function(){
	 	n1 = $("#vector").val().split(',');
	  $("#resultado").val( n1.filter(Boolean) );
	});
</script><?php /**PATH /home/fmiskinich/proyectos/test/resources/views/punto3.blade.php ENDPATH**/ ?>