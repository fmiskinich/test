
<form>
  <div class="form-group row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Palabra</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="palabra" placeholder="Ingrese una palabra">
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Resultado</label>
    <div class="col-sm-10">
      <textarea class="form-control" id="resultado"></textarea>
    </div>
  </div>
</form>	
<center>
  <button type="button" class="btn btn-primary" id="boton_palindromo">Calcular</button>
</center>

<script type="text/javascript">
$(function(){
        $("#boton_palindromo").click(function(){
        	
            cadena = $("#palabra").val();
            $.ajax({
                url:'/palindromo',
                data:{'cadena':cadena},
                type:'post',
                success: function(response){
                    $("#resultado").html(response);
                },
                error:function(response){
                    
                }
            });

        });
    });	

</script><?php /**PATH /home/fmiskinich/proyectos/test/resources/views/punto6.blade.php ENDPATH**/ ?>