<?php 
$array = array(
    '1',array(2,3),
    array(4,5,array("Buenos Dias"))
 );

?>
<form>
  <div class="form-group row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Array</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="vector" value="<?php echo e(json_encode( $array)); ?>">
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Resultado</label>
    <div class="col-sm-10">
    	<div id="resultado" class="form-control">
      	</div>
      </textarea> 
    </div>
  </div>
</form>	

<center>
  <button type="button" class="btn btn-primary" id="boton_arreglo">Calcular</button>
</center>
<script>
$(function(){
        $("#boton_arreglo").click(function(){
            cadena = $("#vector").val();
            $.ajax({
                url:'/flatten',
                data:{'cadena':cadena},
                type:'post',
                success: function(response){
                    $("#resultado").html("<pre>"+response+"</pre>");
                },
                error:function(response){
                    
                }
            });

        });
    });	
</script><?php /**PATH /home/fmiskinich/proyectos/test/resources/views/punto4.blade.php ENDPATH**/ ?>