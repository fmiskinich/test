<?php

namespace App\Helpers;
 
class Helper {
    /**
     * @param int $user_id User-id
     * 
     * @return string
     */
    public static function removeEspecialKeys(&$string)
    {
    	$special = array(',','.',';','-');
    	foreach($special as $s)
    	{
    		$string = str_replace($s,'',$string);
    	}
    	return $string;
    }


    public static function count_words($string)
    {
    	Helper::removeEspecialKeys($string);
		return json_encode(array_count_values(explode(' ',$string)));
    }

    public static function palindromo($string)
    {
    	$string = str_replace(' ','', $string);
    	if(str_split($string) != array_reverse(str_split($string)))
    	{
    		return "No es palindromo";
    	}
    	return "Es palindromo";
    }

    public static function flatten($array) {
	    $return = array();
    	array_walk_recursive($array, function($a) use (&$return) { $return[] = $a; });
    	return $return;
    }

    public static function JSON2Array(&$data){
    	$data = (array) json_decode(stripslashes($data));
	}

}