
<form>
  <div class="form-group row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Array</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="vector" placeholder="Ingrese numeros separados por coma">
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Resultado</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="resultado" placeholder="Resultado" disabled="disabled">
    </div>
  </div>
</form>	

<center>
  <button type="button" class="btn btn-primary" id="boton_mayor">Calcular</button>
</center>
<script>


$("#boton_mayor").click(function(){
 	n1 = $("#vector").val().split(',');
  $("#resultado").val( getMaxOfArray(n1) );
});

function getMaxOfArray(numArray) {
  return Math.max.apply(null, numArray);
}

myArrClean = myArr.filter(Boolean);

</script>