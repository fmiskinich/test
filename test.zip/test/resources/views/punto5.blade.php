
<form>
  <div class="form-group row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Cadena</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="frase" placeholder="Ingrese una frase">
    </div>
  </div>
  <div class="form-group row">
    <label class="col-sm-2 col-form-label">Resultado</label>
    <div class="col-sm-10">
      <textarea class="form-control" id="resultado"></textarea>
    </div>
  </div>
</form>	
<center>
  <button type="button" class="btn btn-primary" id="boton_string">Calcular</button>
</center>

<script type="text/javascript">
$(function(){
        $("#boton_string").click(function(){
        	
            cadena = $("#frase").val();
            $.ajax({
                url:'/string_to_array',
                data:{'cadena':cadena},
                type:'post',
                success: function(response){
                    $("#resultado").html(response);
                },
                error:function(response){
                    
                }
            });

        });
    });	

</script>